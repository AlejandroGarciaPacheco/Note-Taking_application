-- insert into Note (NotepadID, NoteBody, NoteType)
-- values (1, 'aaa', 'plain')
--
select *
from Note;
--
delete from Note
