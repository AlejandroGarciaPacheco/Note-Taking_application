package CloudCompCW.NotePadManager;

public enum NoteType {
    Plain,
    BulletList,
    NumberedList,
}
